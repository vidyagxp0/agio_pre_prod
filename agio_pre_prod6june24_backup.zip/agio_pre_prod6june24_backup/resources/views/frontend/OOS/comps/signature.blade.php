<div id="CCForm17" class="inner-block cctabcontent">
    <div class="inner-block-content">
        <div class="sub-head">
            Activity Log
        </div>
        <div class="row">

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Agenda">Preliminary Lab Inves. Done By</label>
                    <div class="static"></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Agenda">Preliminary Lab Inves. Done On</label>
                    <div class="Date"></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Team">Pre. Lab Inv. Conclusion By</label>
                    <div class="static"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Team">Pre. Lab Inv. Conclusion On</label>
                    <div class="Date"></div>
                </div>
            </div>

            <div class="col-6">
                <div class="group-input">
                    <label for="Audit Comments"> Pre.Lab Invest. Review By </label>
                    <div class="static"></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Attachments">Pre.Lab Invest. Review On</label>
                    <div class="Date"></div>
                </div>
            </div>


            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Attachments">Phase II Invest. Proposed By</label>
                    <div class="static"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Attachments">Phase II Invest. Proposed On</label>
                    <div class="Date"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Response Completed By"> Phase II QC Review Done By</label>
                    <div class=" static"></div>

                </div>
            </div>
            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Response Completed On">Phase II QC Review Done On</label>
                    <div class="date"></div>

                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Attachments">Additional Test Proposed By</label>
                    <div class=" static"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Attachments">Additional Test Proposed On</label>
                    <div class="date"></div>
                </div>
            </div>


            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Attachments">OOS Conclusion Complete By</label>
                    <div class=" static"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Attachments">OOS Conclusion Complete On</label>
                    <div class="date"></div>
                </div>
            </div>


            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Attachments">CQ Review Done By</label>
                    <div class=" static"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Attachments">CQ Review Done On</label>
                    <div class="date"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Attachments">Disposition Decision Done by</label>
                    <div class=" static"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Audit Attachments">Disposition Decision Done On</label>
                    <div class="date"></div>
                </div>
            </div>


            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Reference Recores">Reopen Addendum Complete By

                    </label>
                    <div class=" static"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Reference Recores">Reopen Addendum Complete on

                    </label>
                    <div class="date"></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Reference Recores">Addendum Approval Completed By

                    </label>
                    <div class=" static"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Reference Recores">Reopen Addendum Complete on

                    </label>
                    <div class="date"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Reference Recores">Addendum Execution Done By

                    </label>
                    <div class=" static"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Reference Recores">Addendum Execution Done On

                    </label>
                    <div class="date"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Reference Recores">Addendum Review Done By

                    </label>
                    <div class=" static"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Reference Recores">Addendum Review Done On

                    </label>
                    <div class="date"></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Reference Recores">Verification Review Done By
                    </label>
                    <div class=" static"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="group-input">
                    <label for="Reference Recores">Verification Review Done On

                    </label>
                    <div class="date"></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="group-input">
                    <label for="submitted by">Submitted By :</label>
                    <div class="static"></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="group-input">
                    <label for="submitted on">Submitted On :</label>
                    <div class="Date"></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="group-input">
                    <label for="cancelled by">Cancelled By :</label>
                    <div class="static"></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="group-input">
                    <label for="cancelled on">Cancelled On :</label>
                    <div class="Date"></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="group-input">
                    <label for="More information required By">More information required By :</label>
                    <div class="static"></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="group-input">
                    <label for="More information required On">More information required On :</label>
                    <div class="Date"></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="group-input">
                    <label for="completed by">Completed By :</label>
                    <div class="static"></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="group-input">
                    <label for="completed on">Completed On :</label>
                    <div class="Date"></div>
                </div>
            </div>

        </div>

        <div class="button-block">
            <button type="submit" id="ChangesaveButton" class="saveButton">Save</button>
            <button type="button" class="backButton" onclick="previousStep()">Back</button>
            <button type="button" id="ChangeNextButton" class="nextButton"
                onclick="nextStep()">Next</button>
            <button type="button"> <a href="{{ url('rcms/qms-dashboard') }}" class="text-white">
                    Exit </a> </button>
        </div>
    </div>
</div>