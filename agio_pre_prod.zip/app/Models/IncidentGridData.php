<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IncidentGridData extends Model
{
    use HasFactory;
    protected $table = "incident_grid_datas";
}
