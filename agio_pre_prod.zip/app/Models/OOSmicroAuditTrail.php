<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OOSmicroAuditTrail extends Model
{

    use HasFactory;
    protected $table = 'o_o_s__micro_audit_trials';
}
