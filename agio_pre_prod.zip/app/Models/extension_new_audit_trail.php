<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class extension_new_audit_trail extends Model
{
    use HasFactory;
}
