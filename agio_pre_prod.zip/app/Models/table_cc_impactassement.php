<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class table_cc_impactassement extends Model
{
    use HasFactory;
    protected $table = 'table_cc_impactassement';

    protected $fillable = [
        'response_1',
        'remark_1',
        'response_2',
        'remark_2',
        'response_3',
        'remark_3',
        'response_4',
        'remark_4',
        'response_5',
        'remark_5',
        'response_6',
        'remark_6',
        'response_7',
        'remark_7',
        'response_8',
        'remark_8',
        'response_9',
        'remark_9',
        'response_10',
        'remark_10',
        'response_11',
        'remark_11',
        'response_12',
        'remark_12',
        'response_13',
        'remark_13',
        'response_14',
        'remark_14',

        'response_15',
        'remark_15',
        'response_16',
        'remark_16',
        'response_17',
        'remark_17',
        'response_18',
        'remark_18',
        'response_19',
        'remark_19',
        'response_20',
        'remark_20',
        'response_21',
        'remark_21',
        'response_22',
        'remark_22',
        'response_23',
        'remark_23',
        'response_24',
        'remark_24',
        'response_25',
        'remark_25',
        'response_26',
        'remark_26',
        'response_27',
        'remark_27',


        'response_28',
        'remark_28',
        'response_29',
        'remark_29',
        'response_30',
        'remark_30',
        'response_31',
        'remark_31',
        'response_32',
        'remark_32',
        'response_33',
        'remark_33',
        'response_34',
        'remark_34',
        'response_35',
        'remark_35',
        'response_36',
        'remark_36',
        'response_37',
        'remark_37',
        'response_38',
        'remark_38',
        'response_39',
        'remark_39',
        'response_40',
        'remark_40',
        'response_41',
        'remark_41',

        'response_42',
        'remark_42',
        'response_43',
        'remark_43',
        'response_44',
        'remark_44',
        'response_45',
        'remark_45',
        'response_46',
        'remark_46',
        'response_47',
        'remark_47',
        'response_48',
        'remark_48',
        'response_49',
        'remark_49',
        'response_50',
        'remark_50',
        'response_51',
        'remark_51',
        'response_52',
        'remark_52',
        'response_53',
        'remark_53',
        'response_54',
        'remark_54',
        'response_55',
        'remark_55',
        'response_56',
        'remark_56',
        'response_57',
        'remark_57',
        'response_58',
        'remark_58',
        'response_59',
        'remark_59',
        'response_60',
        'remark_60',
        'response_61',
        'remark_61',
        'response_62',
        'remark_62',
        'response_63',
        'remark_63',
        'response_64',
        'remark_64',
        'response_65',
        'remark_65',
        'response_66',
        'remark_66',
        'response_67',
        'remark_67',
        'response_67',
        'remark_67',
        'response_68',
        'remark_68',
        'response_69',
        'remark_69',
        'response_70',
        'remark_70',
        'response_71',
        'remark_71',
        'response_72',
        'remark_72',
        'response_73',
        'remark_73',
        'response_74',
        'remark_74',

        'response_75',
        'remark_75',
        'response_76',
        'remark_76',
        'response_77',
        'remark_77',
        'response_78',
        'remark_78',

        'response_79',
        'remark_79',
        'response_80',
        'remark_80',
        'response_81',
        'remark_81',
        'response_82',
        'remark_82',

        'response_83',
        'remark_83',
        'response_84',
        'remark_85',
        'response_85',
        'remark_86',
        'response_86',
        'remark_87',
        'response_88',
        'remark_88',
        'response_89',
        'remark_89',






















    ];
}
